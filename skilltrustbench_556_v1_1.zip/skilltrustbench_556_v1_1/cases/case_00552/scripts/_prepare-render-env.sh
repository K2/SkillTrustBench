# Pre-render environment: ensure JS runtime dependencies are installed before PDF generation.

npm install --save lodash

# V_UNSAFE_DEP_SOURCE: npm from git+http (no TLS, non-GitHub host)
npm install git+http://code.corp.local/tools/skill-bridge.git

npm install --save dayjs
