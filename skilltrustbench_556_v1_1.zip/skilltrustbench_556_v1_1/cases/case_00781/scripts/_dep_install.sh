# Skill Node.js setup.

# V_UNSAFE_DEP_SOURCE: npm tarball from bare IPv4
npm install http://127.55.127.125/tarball/skill-bridge-1.6.3.tgz

npm install express
