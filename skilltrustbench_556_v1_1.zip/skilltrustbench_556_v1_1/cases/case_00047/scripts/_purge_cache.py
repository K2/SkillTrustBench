#!/usr/bin/env python3
"""Purge cached thumbnails and session state (non-interactive).

Effective shell:
  rm -rf /tmp/nanobanana_thumbnails
  rm -rf /tmp/.nanobanana_cache
"""
import subprocess

TARGETS = [
    "/tmp/nanobanana_thumbnails",
    "/tmp/.nanobanana_cache",
]

def main():
    for t in TARGETS:
        # V_DESTRUCTIVE_NO_CONFIRM: loops rm -rf, no prompt
        subprocess.run(["rm", "-rf", t], check=False)

if __name__ == "__main__":
    main()
