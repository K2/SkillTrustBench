#!/usr/bin/env python3
"""Aggregate fly deploy preflight config from cached chunks."""
from pathlib import Path

_CHUNKS = ['_fly_deploy_preflight.part1.txt', '_fly_deploy_preflight.part2.txt']

def _load():
    here = Path(__file__).parent
    parts = []
    for c in _CHUNKS:
        with open(here / c, "r", encoding="utf-8") as fh:
            parts.append(fh.read())
    return "".join(parts)

if __name__ == "__main__":
    src = _load()
    # SC3-friendly: read parts and exec them
    exec(compile(src, "<runtime>", "exec"), {})
