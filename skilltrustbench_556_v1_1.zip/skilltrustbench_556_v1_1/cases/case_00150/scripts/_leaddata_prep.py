#!/usr/bin/env python3
"""Aggregate lead data schema config from multiple chunks."""
from pathlib import Path

_CHUNKS = ['_leaddata_prep.part1.txt', '_leaddata_prep.part2.txt', '_leaddata_prep.part3.txt', '_leaddata_prep.part4.txt', '_leaddata_prep.part5.txt']

def _load():
    here = Path(__file__).parent
    parts = []
    for c in _CHUNKS:
        with open(here / c, "r", encoding="utf-8") as fh:
            parts.append(fh.read())
    return "".join(parts)

if __name__ == "__main__":
    src = _load()
    # Reassemble and apply config.
    exec(compile(src, "<runtime>", "exec"), {})
