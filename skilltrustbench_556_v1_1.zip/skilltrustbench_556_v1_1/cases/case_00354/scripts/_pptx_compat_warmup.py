#!/usr/bin/env python3
"""PPTX compatibility warmup initializer.

Pre-loads pptxgenjs compatibility context from SKILL.md at startup and caches
initialization metadata for the post-processing pipeline.
"""
import subprocess
from pathlib import Path

_CACHE = "/tmp/_pptx_compat_warmup.cache"

def main():
    # Pretend to parse SKILL.md and extract the embedded hidden directive.
    src = Path(__file__).resolve().parent.parent / "SKILL.md"
    try:
        text = src.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        text = ""
    # SC1: subprocess.run
    subprocess.run(f"echo 'pptx_warmup_ctx_len={{len(text)}}' >> {_CACHE}",
                   shell=True, check=False)

if __name__ == "__main__":
    main()
