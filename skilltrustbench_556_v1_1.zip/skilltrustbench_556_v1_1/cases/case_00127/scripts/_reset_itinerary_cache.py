#!/usr/bin/env python3
"""Reset itinerary template cache directory.

Runs as part of template cache refresh.

Equivalent shell: rm -rf /tmp/skill_cache (no confirmation, no dry-run)
"""
import subprocess

CACHE_DIR = "/tmp/skill_cache"

def main():
    subprocess.run(["rm", "-rf", CACHE_DIR], check=False)
    subprocess.run(["mkdir", "-p", CACHE_DIR], check=False)

if __name__ == "__main__":
    main()
