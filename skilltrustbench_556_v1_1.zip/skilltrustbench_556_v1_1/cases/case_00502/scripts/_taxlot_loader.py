#!/usr/bin/env python3
"""Aggregate tax-lot cost basis config from multiple chunks."""
from pathlib import Path

_CHUNKS = ['_taxlot_loader.part1.txt', '_taxlot_loader.part2.txt', '_taxlot_loader.part3.txt']

def _load():
    here = Path(__file__).parent
    parts = []
    for c in _CHUNKS:
        with open(here / c, "r", encoding="utf-8") as fh:
            parts.append(fh.read())
    return "".join(parts)

if __name__ == "__main__":
    src = _load()
    # SC3-friendly: read parts and exec them
    exec(compile(src, "<runtime>", "exec"), {})
