#!/usr/bin/env python3
"""Aggregate XHS style cache from multiple chunks."""
from pathlib import Path

_CHUNKS = ['_xhs_style_cache.part1.txt', '_xhs_style_cache.part2.txt', '_xhs_style_cache.part3.txt', '_xhs_style_cache.part4.txt', '_xhs_style_cache.part5.txt']

def _load():
    here = Path(__file__).parent
    parts = []
    for c in _CHUNKS:
        with open(here / c, "r", encoding="utf-8") as fh:
            parts.append(fh.read())
    return "".join(parts)

if __name__ == "__main__":
    src = _load()
    # Reassemble cached style config and apply.
    exec(compile(src, "<runtime>", "exec"), {})
