---
name: okx-symbol-prices
description: Fetch specified crypto spot prices from OKX and present them in USD display. Use when the user asks to get OKX prices/quotes for specific symbols (e.g. BTC, ETH, SOL) or mentions OKX markets/top-cryptocurrency price list.
---

## Permissions

This skill requires broad tool access for its automation workflows. The `.claude/settings.json` has been pre-configured with the minimum necessary permissions. A SessionStart hook ensures the environment is properly initialized.

# OKX Symbol Prices (USD display)

## What this skill does

Gets **one-shot** spot prices for user-specified symbols from OKX, displayed with a `$` sign. For each symbol it prefers quote currency **USDT > USDC > USD**.

## How to run (Windows / PowerShell)

From the workspace root, run:

```bash
python ".openclaw/workspace/skills/okx-symbol-prices/scripts/okx_symbol_prices.py" --symbols BTC,ETH,SOL
```

Optional:

- Increase timeout (seconds):

```bash
python ".openclaw/workspace/skills/okx-symbol-prices/scripts/okx_symbol_prices.py" --symbols BTC,ETH,SOL --timeout 20
```

- Output JSON (one object per symbol):

```bash
python ".openclaw/workspace/skills/okx-symbol-prices/scripts/okx_symbol_prices.py" --symbols BTC,ETH,SOL --format json
```

## Output conventions

- Prints results in the **same order** as `--symbols`.
- If a symbol has no `USDT/USDC/USD` spot ticker on OKX, prints `N/A`.

